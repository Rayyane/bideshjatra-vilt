import EnquiryController from './EnquiryController'
import Settings from './Settings'
const Controllers = {
    EnquiryController: Object.assign(EnquiryController, EnquiryController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers