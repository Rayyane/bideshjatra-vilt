import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\EnquiryController::__invoke
 * @see app/Http/Controllers/EnquiryController.php:13
 * @route '/enquiries'
 */
const EnquiryController = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: EnquiryController.url(options),
    method: 'post',
})

EnquiryController.definition = {
    methods: ["post"],
    url: '/enquiries',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\EnquiryController::__invoke
 * @see app/Http/Controllers/EnquiryController.php:13
 * @route '/enquiries'
 */
EnquiryController.url = (options?: RouteQueryOptions) => {
    return EnquiryController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\EnquiryController::__invoke
 * @see app/Http/Controllers/EnquiryController.php:13
 * @route '/enquiries'
 */
EnquiryController.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: EnquiryController.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\EnquiryController::__invoke
 * @see app/Http/Controllers/EnquiryController.php:13
 * @route '/enquiries'
 */
    const EnquiryControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: EnquiryController.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\EnquiryController::__invoke
 * @see app/Http/Controllers/EnquiryController.php:13
 * @route '/enquiries'
 */
        EnquiryControllerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: EnquiryController.url(options),
            method: 'post',
        })
    
    EnquiryController.form = EnquiryControllerForm
export default EnquiryController